#!/usr/bin/python3
import os
# import re
import json

luciBase = {
    "admin/nas": {
        "title": "NAS",
        "order": 80,
        "action": {
            "type": "firstchild",
            "recurse": True
        }
    },
    "admin/nlbw": {
        "title": "Bandwidth Monitor",
        "order": 100,
        "action": {
            "type": "firstchild",
            "recurse": True
        }
    },
}

file = 'feeds/luci/modules/luci-base/root/usr/share/luci/menu.d/luci-base.json'

with open(file) as f:
    config = json.load(f)
# if 'admin/vpn' in config:
#     del config['admin/vpn']

s = {}
for i in config:
    s[i] = config[i]
    if i == 'admin/vpn':
        for j in luciBase:
            s[j] = luciBase[j]

# print(s)
with open(file, 'w') as f:
    json.dump(s, f, indent='\t')


